<div class="container header-main-area header-3-wrapper">	
		<?php get_template_part( 'sections/headers/logo'); ?>

		<?php get_template_part( 'sections/headers/navigation'); ?>
</div>